-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 19-01-2026 a las 15:41:01
-- Versión del servidor: 11.8.3-MariaDB-log
-- Versión de PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `u880452948_S_Escolar`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `escuelas`
--

CREATE TABLE `escuelas` (
  `id_escuela` int(11) NOT NULL,
  `nombre_escuela` varchar(255) NOT NULL,
  `siglas` varchar(255) NOT NULL,
  `nivel_estudio` int(255) NOT NULL,
  `max_alumnos` int(11) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `CP` int(11) NOT NULL,
  `N_SEP` varchar(255) NOT NULL,
  `municipio` text NOT NULL,
  `Identidad` varchar(255) NOT NULL,
  `id_identidad_escolar` int(11) NOT NULL,
  `id_zona_escolar` int(255) NOT NULL,
  `id_logo_escuela` int(11) NOT NULL,
  `credencial_ruta_frente` text NOT NULL,
  `credencial_ruta_reverso` text NOT NULL,
  `estatus` int(11) NOT NULL COMMENT '1=inactivo 0=activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `escuelas`
--

INSERT INTO `escuelas` (`id_escuela`, `nombre_escuela`, `siglas`, `nivel_estudio`, `max_alumnos`, `direccion`, `CP`, `N_SEP`, `municipio`, `Identidad`, `id_identidad_escolar`, `id_zona_escolar`, `id_logo_escuela`, `credencial_ruta_frente`, `credencial_ruta_reverso`, `estatus`) VALUES
(0, 'tesi', 'sin asignar', 0, 0, 'sin asignar', 0, 'sinasignar', '', 'sin asignar', 0, 0, 0, '', '', 1),
(1, 'Escuela Prueba Denedig', 'DENEDIG', 1, 1510, 'Paraje San Isidro S/N, Barrio Tecamachalco, La Paz EDOMEX', 56400, '15EIT0005Y', '', 'Estado de México', 1, 0, 1, '../sistema_credenciales_dinamicas/1/frontal.php', '../sistema_credenciales_dinamicas/1/reverso.php', 1),
(2, 'Escuela Prueba Denedig DEMO', 'DENEDIG', 0, 300, 'cra 12 av 13 cuautemoc', 56535, '23TYC2465', '', 'ESTADO DE MÉXICO', 0, 0, 0, '', '', 1),
(3, 'TECNOLÓGICO DE ESTUDIOS SUPERIORES DE CHIMALHUACÁN', 'TESCHI', 0, 0, 'cra 12 av 13 cuautemoc', 56535, '23TYC2465', '', 'ESTADO DE MÉXICO', 0, 0, 0, '', '', 1),
(4, 'UNIVERSIDAD TRES CULTURAS', 'UTC', 0, 0, 'cra 12 av 13 cuautemoc', 56535, '23TYC2455', '', 'ESTADO DE MÉXICO', 0, 0, 0, '', '', 1),
(5, 'UNIVERSIDAD MEXIQUENSE DEL BICENTENARIO', 'UMB', 0, 0, 'Av escondida ', 56500, '12HK1VI2Y3', '', 'ESTADO DE MÉXICO', 0, 0, 0, '', '', 1),
(6, 'EPO. NÚM 253', 'EPO 253', 0, 500, 'C. Galeana S/N, 56960 San Pedro Nexapa, Méx.', 56500, '15EBH0442J', '', 'estado de mexico', 3, 0, 3, '', '', 1),
(7, 'EPO. NÚM 50', 'EPO 50', 0, 1000, 'Xolaltenco S/N, 56990 Ecatzingo de Hidalgo, Méx.', 56990, '0000000', '', 'Puebla', 3, 0, 3, '', '', 1),
(8, 'EPO. NÚM 54', 'EPO 54', 0, 0, 'AV. AV.SOLIDARIDAD NAL.ESQ.AV.IGNACIO ZARAGOZA COL.UNION DE GUADALUPE,CHALCO C.P 56606 MUNICIPIO CHALCO', 56606, '0', '', 'CHALCO', 3, 0, 3, '', '', 1),
(9, 'EPO. NÚM 88', 'EPO 88', 0, 0, 'AV. MOCTEZUMA S/N ESQUINA PONIENTE 14 VALLE DE XICO TERCERA SECCIÓN MPIO.VALLE DE CHALCO', 0, '0', '', 'VALLE DE CHALCO', 3, 0, 3, '', '', 1),
(10, 'EPO.NÚM.92', 'EPO 92', 0, 0, 'DIAGONAL AGRICULTURA NO.45 EN SAN JUAN TLALPIZAHUAC MPIO.VALLE DE CHALCO', 0, '0', '', 'VALLE DE CHALCO', 1, 0, 1, '', '', 1),
(11, 'EPO.NÚM.96', 'EPO 96', 0, 0, 'SUR 3 ESQUINA LOMBARDO TOLEDANO LOTE 2 MZN.11 COL. NIÑOS HEROES SEGUNDA SECCIÓN MPIO. VALLE DE CHALCO', 0, '0', '', 'VALLE DE CHALCO', 1, 0, 1, '', '', 1),
(12, 'EPO. NÚM 123', 'EPO 123', 0, 0, 'AV.LEONA VICARIO ESQUINA ORIENTE 7 COL.INDEPENDENCIA MPIO. VALLE DE CHALCO', 0, '0', '', 'VALLE DE CHALCO', 1, 0, 1, '', '', 1),
(13, 'EPO. NÚM 300', 'EPO 300', 0, 0, 'CALLE SUR 6 S/N COL.GUADALUPANA SEGUNDA SECCIÓN MPIO. VALLE DE CHALCO', 0, '0', '', 'VALLE DE CHALCO', 1, 0, 0, '', '', 1),
(14, 'EPO. NÚM 326', 'EPO 326', 0, 0, 'AV.HERMENEGILDO GALEANA Y ORIENTE 8 S/N COLONIA SANTA CRUZ VALLE DE CHALCO', 0, '0', '', 'VALLE DE CHALCO', 1, 0, 0, '', '', 1),
(15, 'EPO. NÚM 340', 'EPO 340', 0, 0, 'PONIENTE 18 SUR ¨A¨  XICO 3RA SECCIÓN MPIO. VALLE DE CHALCO', 0, '0', '', 'VALLE DE CHALCO', 1, 0, 0, '', '', 1),
(16, 'EPO. NÚM 348', 'EPO 348', 0, 0, 'PONIENTE 4 MZN. 714 LOT.12 COL.CONCEPCIÓN MPIO. VALLE DE CHALCO', 0, '0', '', 'VALLE DE CHALCO', 1, 0, 0, '', '', 1),
(17, 'EPO. NÚM 354', 'EPO 354', 0, 0, 'AV.UNIÓN S/N COL.FRATERNIDAD ANTORCHISTA,CHALCO DE DIAZ COVARRUBIAS,EDO DE MÉX MPIO CHALCO', 0, '0', '', 'CHALCO', 1, 0, 0, '', '', 1),
(18, 'EPO. NÚM 357', 'EPO 357', 0, 0, 'CALLE EL ROSARIO ,COL,SAN MARTIN XICO LA LAGUNA.MPIO. DE VALLE DE CHALCO SOLIDARIDAD', 0, '0', '', 'VALLE DE CHALCO', 1, 0, 0, '', '', 1),
(19, 'EPO. NÚM 362', 'EPO 362', 0, 0, 'AV.ANAHUAC S/N COL.JARDIN,MPIO. DE VALLE DE CHALCO SOLIDARIDAD', 0, '0', '', 'VALLE DE CHALCO ', 1, 0, 0, '', '', 1),
(20, 'PREPARATORIA OFICIAL No.29', 'Prep. Of. No. 29', 0, 1337, 'GRAL.JOSE C. CONTRERAS S/N, TEPETLIXPA,MEX.', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(21, 'PREPARATORIA OFICIAL No.50', 'Prep. Of. No. 50', 0, 0, 'AV.PUEBLA S/N.ECATZINGO,MEX.', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(22, 'PREPARATORIA OFICIAL No.66', 'Prep. Of. No. 66', 0, 0, '29 DE AGOSTO S/N,COCOTITLAN,MEX', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(23, 'PREPARATORIA OFICIAL No.119', 'Prep. Of. No. 119', 0, 0, 'CALLE INSURGENTES S/N SAN JUAN TEHUIXITLAN,ATLAUTLA,MEX.', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(24, 'PREPARATORIA OFICIAL No.102', 'Prep. Of. No. 102', 0, 0, 'CERRADA TEPOZANES, CAM. TEZOPILO S/N TLALMANALCO.MEX.', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(25, 'PREPARATORIA OFICIAL No.130', 'Prep. Of. No. 130', 0, 0, 'LA ESTACIÓN S/N,TENANGO DEL AIRE, MEX.', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(26, 'PREPARATORIA OFICIAL No.177', 'Prep. Of. No. 177', 0, 0, 'PROLONGACIÓN EMILIANO ZAPATA S/N,OZUMBA,MEX', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(27, 'PREPARATORIA OFICIAL No.253', 'Prep. Of. No. 253', 0, 0, 'PROLONGACIÓN GALEANA S/N, SAN PEDRO NEXAPA,AMECAMECA,MEX.', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(28, 'PREPARATORIA OFICIAL No.254', 'Prep. Of. No. 254', 0, 0, 'GUSTAVO BAZ S/N,CUIJINGO, JUCHITEPEC,MEX.', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(29, 'PREPARATORIA OFICIAL No.264', 'Prep. Of. No. 264', 0, 0, 'GUSTAVO BAZ S/N,CUIJINGO, JUCHITEPEC,MEX.', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(30, 'PREPARATORIA OFICIAL No.271', 'Prep. Of. No. 271', 0, 0, 'CAMINO SANTA RITA JOYACAN S/N,SAN ANTONIO ZOYATZINGO,MEX', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(31, 'PREPARATORIA OFICIAL No.283', 'Prep. Of. No. 283', 0, 0, 'SILVESTRE LOPEZ No 187,BARRIO EL CASTILLO,AMECAMECA,MEX', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(32, 'PREPARATORIA OFICIAL No.343', 'Prep. Of. No. 343', 0, 0, 'CALLEJON AMERICA  DEL SUR S/N, SAN ANDRES TLALAMAC,ATLAUTLA,MEX.', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(33, 'PREPARATORIA OFICIAL No.344', 'Prep. Of. No. 344', 0, 0, 'LA CANDELARIA TLAPALA', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(34, 'PREPARATORIA OFICIAL ANEXA A LA NORMAL DE AMECAMECA', 'Prep. Of. Anexa Amecameca', 0, 1200, 'CALLE GARITAS DE MATAMOROS S/N AMECAMECA,MÉX.', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(35, 'COLEGIO REAL CHAPULTEPEC', 'Col. Real Chapultepec', 0, 0, 'AV.CHAPULTEPEC NO.7,BARRIO PANOHAYA,AMECAMECA,MEX', 0, '0', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(36, 'PREPARATORIA OFICIAL No. 55', 'Prep. Of. No. 55', 0, 0, 'C.FRANCISCO I. MADERO MZ. 20 COL. REVOLUClON,CHICOLOAPAN, ESTADO DE MEXICO. C.P. 56370 ', 56370, '15EBH0182N - 15EBH0123Y', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(37, 'PREPARATORIA OFICIAL No.74', 'Prep. Of. No. 74', 0, 1000, 'C.SAN JOSE, ESQ.LA PALMA S/N U.H SAN JOSE DE LA PALM/.IXTAPALUCA ESTADO DE MEXICO.', 56530, '15EBH0170I - 15EBH0155Q', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(38, 'PREPARATORIA OFICIAL No. 122', 'Prep. Of. No. 122', 0, 0, 'C. EMILIANO ZAPATA S/N COL. 20 DE NOVIEMBRE, TLAPACOYA IXTAPALUCA ESTADO DE MEXICO.', 56570, '15EBH0456M - 15EBH0249E', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(39, 'PREPARATORIA OFICIAL No. 124', 'Prep. Of. No. 124', 0, 0, 'AV.UNlON ESQ. FRATERNIDAD S/N COL. CERRO DEL TEJOLOTE, IXTAPALUCA ESTADO DE MEXICO.', 0, '15EBH0247G', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(40, 'PREPARATORIA OFICIAL No. 161', 'Prep. Of. No. 161', 0, 0, 'CIRCUITO PALMERA IMPERIAL ENTRE AV.PRINCIPAL WASHINGTONIANA Y CALLE ARECA S/N, U.H HACIENDA LAS PALMAS, IXTAPALUCA ESTADO DE MEXICO.', 56535, '15EBH0297O -15EBHO312Q', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(41, 'PREPARATORIA OFICIAL No.224', 'Prep. Of. No. 224', 0, 0, 'C. CUCHILLA SAN ISIDRO ESQ. PALMA, COL. EJIDOS DE SANTA MARIA, CHIMALHUACAN ESTADO DE MEXICO.', 56330, '15EBH0412P - 15EBH04O', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(42, 'PREPARA TORIA OFICIAL No. 310', 'Prep. Of. No. 310', 0, 0, 'C. LILAS S/N, COL. IZCALLI AYOTLA,IXTAPALUCA ESTADO DE MEXICO.', 56560, '15EBH0507C', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(43, 'PREPARATORIA OFICIAL No. 350', 'Prep. Of. No. 350', 0, 0, 'AV.TEHUACAN S/N,COL. REY ITZCOATL IXTAPLUCA, ESTADO DE MEXICO ', 0, '15EBH0555M', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(44, 'SUPERVISIÓN ESCOLAR BG 50', 'SUP. ESC. 50', 0, 0, 'FRENTE A EX HACIENDA DE SAN JUAN S/N COL. CASCO DE SAN JUAN CHALCO,CHALCO,MEX, C.P 56600', 56600, '15FMS0159X', '', 'CHALCO', 3, 0, 0, '', '', 1),
(45, 'ESCUELA PREPARATORIA OFICIAL NUM. 30 legacy_r', 'Prep. Of. No. 30 legacy _r', 0, 827, 'FRENTE A EX HACIENDA DE SAN JUAN S/N COL. CASCO DE SAN JUAN CHALCO,CHALCO,MEX, C.P 56601', 56601, '15BH0094T - 15EBH0108F', '', 'CHALCO', 3, 0, 0, '', '', 1),
(46, 'ESCUELA PREPARATORIA OFICIAL NÚM.70', 'Prep. Of. No. 70', 0, 0, 'ANTIGUO CAMINO A TENANGO S/N COL.SAN JOSÉ AXALCO SAN PABLO ATLAZALPAN,CHALCO,MEX ', 56620, '15EBH0161A ', '', 'CHALCO', 3, 0, 0, '', '', 1),
(47, 'ESCUELA PREPARATORIA OFICIAL NÚM.127', 'Prep. Of. No. 127', 0, 0, 'ALVARO OBREGON S/N COL.SAN MIGUEL,SAN MATEO HUITZILZINGO,CHALCO,MEX.', 56625, '15EBH0253R - 15EBH0404G', '', 'CHALCO', 3, 0, 0, '', '', 1),
(48, 'ESCUELA PREPARATORIA OFICIAL NÚM.312', 'Prep. Of. No. 312', 0, 0, 'AV. DEL TRIUNFO MZ. 100 LT.2 COL. NUEVA SAN ISIDRO, CHALCO ESTADO DE MEXICO', 0, '15EBH0509A', '', 'CHALCO', 3, 0, 0, '', '', 1),
(49, 'MODULO ANEXO  A LA ESCUELA PREPARATORIA OFICIAL NÚM.312', 'MOL.ANEX. PREP. OF. 312', 0, 0, 'CALLE SOR JUANA S/N, ESQUINA CON G. NAJERA, DELEGACION NEPANTLA', 0, '15EBH0509A', '', 'NEPANTLA', 3, 0, 0, '', '', 1),
(50, 'ESCUELA PREPARATORIA OFICIAL NÚM.342', 'Prep. Of. No. 342', 0, 0, 'PROLONGACION CALLEJON A LA PAZ S/N, COL. LLANO GRANDE SAN MATEO TEZOQUIAPAN MIRAFLORES, ESTADO DE MEX. ', 56600, '15EBH0547D', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(51, 'ESCUELA PREPARATORIA OFICIAL NÚM.367', 'Prep. Of. No. 367', 0, 0, 'CALLE EMBARCADERO COL. SANTA CATARINA AYOTZINGO, MEXICO.', 56623, '15EBH0018M', '', 'AYOTZINGO', 3, 0, 0, '', '', 1),
(52, 'ESCUELA PREPARATORIA OFICIAL NUM. 374', 'Prep. Of. No. 374', 0, 0, 'CALLE PROLONGACION NIÑO ARTILLERO S/N SAN LUCAS AMALINALCO, CHALCO DE DIAZ COVARRUBIAS, ESTADO DE MEXICO.  ', 56642, '15EBH0025X ', '', 'CHALCO', 3, 0, 0, '', '', 1),
(53, 'ESCUELA PREPARATORIA OFICIAL ANEXA A LA NORMAL DE CHALCO', 'Prep. Of. Anexa Chalco', 0, 0, 'TIZAPA, ESQ. INSURGENTES S/N COL. CASCO DE SAN JUAN CHALCO, MEX.  ', 56600, '15EBP0007Q - 15EBP0041X', '', 'CHALCO', 3, 0, 0, '', '', 1),
(54, 'MODULO ANEXO A  LA ESCUELA PREPARATORIA OFICIAL ANEXA A LA NORMAL DE CHALCO', 'MOL.ANEX. PREP. OF. ANEX. CHALCO', 0, 0, 'CALLE INDEPENDENCIA NUM. 11 SAN MARTIN XICO', 0, '15EBP0007Q', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(55, 'ESCUELA PREPARATORIA PARTICULAR BENITO JUAREZ', 'Prep. Part. Benito Juárez', 0, 0, 'CALLE DALIAS S/N COL. JARDINES DE CHALCO,  CHALCO, MEX. ', 56607, '15PBH6116I ', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(56, 'ESCUELA PREPARATORIA PARTICULAR SOR JUANA INES DE LA CRUZ', 'Prep. Part. Juana Inés', 0, 0, 'CALLEJON DE LA PAZ 6°a SAN MATO TEZOQUIAPAN MIRAFLORES, ESTADO DE MEX.', 56645, '15PBH0112Y ', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(57, 'ESCUELA PREPARATORIA PARTICULAR JAGUARES DE  AMERICA', 'Prep. Part. Jaguares', 4, 500, 'AV J.M. MORELOS 500, SAN GREGORIO CUAUTZINGO, SAN MARTIN CUAUTLALPAN, MEX.  ', 56535, '15EBP0224B ', '', 'ESTADO DE MÉXICO', 3, 0, 0, '', '', 1),
(58, 'Tecnologico de Estudios Superiores Oriente del Estado de México', 'TESCHI', 0, 0, 'sin asignar', 56535, '23TYC2455', '', 'Estado de mexico', 3, 0, 0, '', '', 1),
(59, 'Instituto tecnologico el llano aguascalientes', 'TESCHI', 3, 0, 'sin asignar', 56535, '23TYC2455', '', 'ciudad de mexico', 1, 0, 0, '', '', 1),
(60, 'Tecnologico de Estudios Superiores Oriente del Estado de México', 'ITEL', 4, 0, 'av cuautemoc mz 16 lt 4', 56535, '23TYC2455', '', 'Estado de mexico', 0, 0, 0, '', '', 1),
(61, 'Colegio YOLIZTLI', 'YOLIZTLI', 3, 500, 'AV J.M. MORELOS 500, SAN GREGORIO CUAUTZINGO, SAN MARTIN CUAUTLALPAN, MEX.', 56535, '15PES1446V', '', 'Estado de mexico', 3, 0, 0, '../identidad_escolar/61/credencial_frontal.php', '../identidad_escolar/61/credencial_reverso.php', 1),
(62, 'Lamour', 'Lamour', 5, 10, 'sin asignar', 56500, '0000000', '', 'Estado de mexico', 0, 0, 0, '', '', 1),
(63, 'PREPARATORIA OFICIAL No.342', 'EPO 342', 4, 470, 'sin asignar', 0, '15EBH0547D', 'CHALCO', 'Estado de mexico', 0, 0, 0, '../sistema_credenciales_dinamicas/342/frontal.php', '../sistema_credenciales_dinamicas/342/reverso.php', 1),
(64, 'Escuela Preparatoria oficial número 67', 'EPO 67', 0, 2000, '', 0, '', '', '', 0, 0, 0, '', '', 1),
(65, 'Escuela preparatoria Oficial 344', 'EPO 334', 0, 2000, 'La Candelaria Tlapala', 56647, '15EBH0549B', 'CHALCO', 'Estado de mexico', 0, 0, 0, '', '', 1),
(66, 'ESCUELA PREPARATORIA OFICIAL NÚM.30_1', 'EPO 30 _1', 0, 1000, '', 0, '', '', '', 0, 0, 0, '', '', 1),
(67, 'jaguares_2', '', 0, 1000, '', 0, '', '', '', 0, 0, 0, '', '', 1),
(70, 'Epo 342', 'EPO', 0, 1000, '', 0, '', '', '', 0, 0, 0, '', '', 1),
(71, 'EPO. NÚM 50_1', '', 0, 1000, '', 0, '', '', '', 0, 0, 0, '', '', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `escuelas`
--
ALTER TABLE `escuelas`
  ADD PRIMARY KEY (`id_escuela`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `escuelas`
--
ALTER TABLE `escuelas`
  MODIFY `id_escuela` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
